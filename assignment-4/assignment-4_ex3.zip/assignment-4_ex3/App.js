import { useState } from "react";
import {
  SafeAreaView,
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Linking,
  Alert,
  Platform,
} from "react-native";

const CITIES = ["Tampere", "Helsinki", "Lapland"];

function openURL(url) {
  Linking.canOpenURL(url)
    .then((ok) => (ok ? Linking.openURL(url) : Alert.alert("Cannot open URL", url)))
    .catch((e) => Alert.alert("Error", e.message));
}

function openMap(city) {
  if (Platform.OS === "ios") {
    const url = `http://maps.apple.com/?q=${encodeURIComponent(city + ", Finland")}`;
    openURL(url);
  } else if (Platform.OS === "android") {
    const url = `geo:0,0?q=${encodeURIComponent(city + ", Finland")}`;
    openURL(url);
  } else {
    const url = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
      city + ", Finland"
    )}`;
    openURL(url);
  }
}

function openActivities(city) {
  const q = `things to do in ${city}, Finland`;
  const url = `https://www.google.com/search?q=${encodeURIComponent(q)}`;
  openURL(url);
}

export default function App() {
  const [openCity, setOpenCity] = useState(null);

  return (
    <SafeAreaView style={styles.safe}>
      <Text style={styles.title}>City Quick Actions</Text>

      {CITIES.map((city) => (
        <View key={city} style={styles.card}>
          <TouchableOpacity
            style={styles.cityBtn}
            onPress={() => setOpenCity((c) => (c === city ? null : city))}
          >
            <Text style={styles.cityText}>{city}</Text>
            <Text style={styles.chev}>{openCity === city ? "▾" : "▸"}</Text>
          </TouchableOpacity>

          {openCity === city && (
            <View style={styles.actions}>
              <TouchableOpacity style={[styles.actionBtn, styles.map]} onPress={() => openMap(city)}>
                <Text style={styles.actionText}>Open Map</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionBtn, styles.activities]}
                onPress={() => openActivities(city)}
              >
                <Text style={styles.actionText}>What to do</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>
      ))}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, padding: 16, backgroundColor: "#101114" },
  title: { color: "white", fontSize: 22, fontWeight: "700", marginBottom: 12 },
  card: {
    backgroundColor: "#1a1c22",
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 10,
  },
  cityBtn: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },
  cityText: { color: "white", fontSize: 18, fontWeight: "600" },
  chev: { color: "#9aa0a6", fontSize: 18 },
  actions: { flexDirection: "row", gap: 8, marginTop: 10 },
  actionBtn: {
    flex: 1,
    alignItems: "center",
    paddingVertical: 10,
    borderRadius: 8,
  },
  map: { backgroundColor: "#2b6fff" },
  activities: { backgroundColor: "#14a44d" },
  actionText: { color: "white", fontWeight: "700" },
});
