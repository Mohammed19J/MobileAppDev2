// /utils/speechHelper.js
import * as Speech from 'expo-speech';

// Map language codes to speech voices
const LANGUAGE_VOICE_MAP = {
  'en': 'en-US',
  'es': 'es-ES',
  'fr': 'fr-FR',
  'de': 'de-DE',
  'it': 'it-IT',
  'pt': 'pt-PT',
  'nl': 'nl-NL',
  'ru': 'ru-RU',
  'zh': 'zh-CN',
  'ja': 'ja-JP',
  'ar': 'ar-SA',
  'hi': 'hi-IN',
  'fi': 'fi-FI',
};

export const speak = async (text, languageCode) => {
  try {
    // Stop any ongoing speech first
    await Speech.stop();
    
    // Speak with the appropriate language
    const language = LANGUAGE_VOICE_MAP[languageCode] || 'en-US';
    
    Speech.speak(text, {
      language: language,
      pitch: 1.0,
      rate: 0.9, // Slightly slower for clarity
    });
  } catch (error) {
    console.error('Speech error:', error);
  }
};

export const stopSpeaking = async () => {
  try {
    await Speech.stop();
  } catch (error) {
    console.error('Stop speech error:', error);
  }
};

export const isSpeaking = () => {
  return Speech.isSpeakingAsync();
};
