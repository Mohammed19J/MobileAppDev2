// Project/components/SpeakerButton.js
import React, { useState } from 'react';
import { TouchableOpacity, Text, StyleSheet } from 'react-native';
import { speak, stopSpeaking } from '../utils/speechHelper';

export default function SpeakerButton({
  text,
  language,
  variant = 'full', // 'full' (big blue button) or 'icon' (round icon)
  style,
}) {
  const [isSpeaking, setIsSpeaking] = useState(false);

  const handlePress = async (event) => {
    event?.stopPropagation?.(); // so it doesn't trigger parent touches

    if (!text) return;

    if (isSpeaking) {
      await stopSpeaking();
      setIsSpeaking(false);
    } else {
      setIsSpeaking(true);
      await speak(text, language);
      setTimeout(() => setIsSpeaking(false), text.length * 100);
    }
  };

  if (variant === 'icon') {
    // small round button (history items)
    return (
      <TouchableOpacity
        style={[
          styles.speakerIconButton,
          isSpeaking && styles.speakerIconButtonActive,
          style,
        ]}
        onPress={handlePress}
      >
        <Text style={styles.speakerIconText}>
          {isSpeaking ? '⏸️' : '🔊'}
        </Text>
      </TouchableOpacity>
    );
  }

  // full-width button (result page)
  return (
    <TouchableOpacity
      style={[
        styles.speakerButton,
        isSpeaking && styles.speakerButtonActive,
        style,
      ]}
      onPress={handlePress}
    >
      <Text style={styles.speakerIcon}>{isSpeaking ? '⏸️' : '🔊'}</Text>
      <Text style={styles.speakerText}>
        {isSpeaking ? 'Stop Speaking' : 'Speak Translation'}
      </Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  speakerButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#007AFF',
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
  },
  speakerButtonActive: {
    backgroundColor: '#FF3B30',
  },
  speakerIcon: {
    fontSize: 24,
    marginRight: 10,
  },
  speakerText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  speakerIconButton: {
    backgroundColor: '#007AFF',
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
  },
  speakerIconButtonActive: {
    backgroundColor: '#FF3B30',
  },
  speakerIconText: {
    fontSize: 20,
  },
});
