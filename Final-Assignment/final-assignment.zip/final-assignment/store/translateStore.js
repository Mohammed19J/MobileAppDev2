import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';

const HISTORY_KEY = '@translation_history';
const MAX_HISTORY_LENGTH = 5; // Maximum 5 items in history

const useTranslateStore = create((set, get) => ({
  sourceLang: 'en',
  targetLang: 'es',
  inputText: '',
  resultText: '',
  loading: false,
  error: null,
  history: [],

  setInputText: (text) => set({ inputText: text }),
  setSourceLang: (lang) => set({ sourceLang: lang }),
  setTargetLang: (lang) => set({ targetLang: lang }),
  setResultText: (text) => set({ resultText: text }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),

  // Add translation to history with max length limit
  addToHistory: async (item) => {
    const currentHistory = get().history;
    const newHistory = [item, ...currentHistory]; // Add new item at front
    
    // Keep only the most recent MAX_HISTORY_LENGTH items
    const limitedHistory = newHistory.slice(0, MAX_HISTORY_LENGTH);
    
    set({ history: limitedHistory });
    try {
      await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(limitedHistory));
    } catch (e) {
      console.error('Failed to save history', e);
    }
  },

  // Load history from storage
  loadHistory: async () => {
    try {
      const stored = await AsyncStorage.getItem(HISTORY_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        // Ensure loaded history also respects max length
        const limitedHistory = parsed.slice(0, MAX_HISTORY_LENGTH);
        set({ history: limitedHistory });
      }
    } catch (e) {
      console.error('Failed to load history', e);
    }
  },

  // Clear all history
  clearHistory: async () => {
    set({ history: [] });
    try {
      await AsyncStorage.removeItem(HISTORY_KEY);
    } catch (e) {
      console.error('Failed to clear history', e);
    }
  },
}));

export default useTranslateStore;
