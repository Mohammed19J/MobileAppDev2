import React, { useEffect } from 'react';
import {
  View,
  Text,
  Button,
  ActivityIndicator,
  StyleSheet,
} from 'react-native';
import useTranslateStore from '../store/translateStore';
import { translateText } from '../data/translateService';
import SpeakerButton from '../components/SpeakerButton';

export default function ResultScreen({ navigation }) {
  const inputText = useTranslateStore(state => state.inputText);
  const sourceLang = useTranslateStore(state => state.sourceLang);
  const targetLang = useTranslateStore(state => state.targetLang);
  const setResultText = useTranslateStore(state => state.setResultText);
  const resultText = useTranslateStore(state => state.resultText);
  const loading = useTranslateStore(state => state.loading);
  const setLoading = useTranslateStore(state => state.setLoading);
  const error = useTranslateStore(state => state.error);
  const setError = useTranslateStore(state => state.setError);
  const addToHistory = useTranslateStore(state => state.addToHistory);

  useEffect(() => {
    setLoading(true);
    setError(null);
    translateText({ q: inputText, source: sourceLang, target: targetLang })
      .then((translated) => {
        // Decode URL-encoded spaces before saving/displaying
        const decodedText = decodeURIComponent(translated);
        setResultText(decodedText);

        // Save to history with decoded text
        addToHistory({
          id: Date.now().toString(),
          sourceText: inputText,
          translatedText: decodedText,
          sourceLang,
          targetLang,
          timestamp: new Date().toISOString(),
        });

        setLoading(false);
      })
      .catch((err) => {
        setError(err.message);
        setLoading(false);
      });
  }, [
    inputText,
    sourceLang,
    targetLang,
    setLoading,
    setError,
    setResultText,
    addToHistory,
  ]);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Translation Result</Text>

      {loading ? (
        <ActivityIndicator size="large" color="#007AFF" />
      ) : error ? (
        <Text style={styles.error}>Error: {error}</Text>
      ) : (
        <View>
          <Text style={styles.label}>
            Original ({sourceLang.toUpperCase()}):
          </Text>
          <View style={styles.textBox}>
            <Text style={styles.text}>{inputText}</Text>
          </View>

          <Text style={styles.label}>
            Translated ({targetLang.toUpperCase()}):
          </Text>
          <View style={styles.resultBox}>
            <Text style={styles.resultText}>{resultText}</Text>
          </View>

          {/* Speaker Button (full variant) */}
          <SpeakerButton
            text={resultText}
            language={targetLang}
            variant="full"
          />
        </View>
      )}

      <View style={styles.buttonContainer}>
        <Button title="← Go Back" onPress={() => navigation.goBack()} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  label: {
    fontSize: 14,
    color: '#666',
    marginTop: 15,
    marginBottom: 8,
    fontWeight: '600',
  },
  textBox: {
    backgroundColor: '#f5f5f5',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#999',
  },
  text: {
    fontSize: 16,
    color: '#333',
  },
  resultBox: {
    backgroundColor: '#E3F2FD',
    padding: 12,
    borderRadius: 8,
    borderLeftWidth: 3,
    borderLeftColor: '#007AFF',
  },
  resultText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#007AFF',
  },
  error: {
    color: 'red',
    fontSize: 16,
    textAlign: 'center',
  },
  buttonContainer: {
    marginTop: 30,
  },
});
