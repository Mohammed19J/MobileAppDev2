// /data/translateService.js
const BASE_URL = 'https://api.mymemory.translated.net/get';

export async function translateText({ q, source = 'en', target = 'es' }) {
  try {
    const url = `${BASE_URL}?q=${encodeURIComponent(q)}&langpair=${source}|${target}`;
    const res = await fetch(url);
    
    if (!res.ok) throw new Error('Network response was not ok');
    const data = await res.json();
    return data.responseData.translatedText;
  } catch (error) {
    throw error;
  }
}
