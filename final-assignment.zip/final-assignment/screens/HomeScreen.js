import React, { useEffect, useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import useTranslateStore from '../store/translateStore';
import { LANGUAGES } from '../config/languages';
import { speak, stopSpeaking } from '../utils/speechHelper';

export default function HomeScreen({ navigation }) {
  const inputText = useTranslateStore(state => state.inputText);
  const setInputText = useTranslateStore(state => state.setInputText);
  const sourceLang = useTranslateStore(state => state.sourceLang);
  const setSourceLang = useTranslateStore(state => state.setSourceLang);
  const targetLang = useTranslateStore(state => state.targetLang);
  const setTargetLang = useTranslateStore(state => state.setTargetLang);
  const history = useTranslateStore(state => state.history);
  const loadHistory = useTranslateStore(state => state.loadHistory);
  const clearHistory = useTranslateStore(state => state.clearHistory);

  const [speakingId, setSpeakingId] = useState(null);

  // Load history when screen mounts
  useEffect(() => {
    loadHistory();
  }, [loadHistory]);

  const handleHistoryItemPress = (item) => {
    setInputText(item.sourceText);
    setSourceLang(item.sourceLang);
    setTargetLang(item.targetLang);
  };

  const handleSpeakHistory = async (item, event) => {
    // Stop event from bubbling to parent TouchableOpacity
    event?.stopPropagation();
    
    if (speakingId === item.id) {
      await stopSpeaking();
      setSpeakingId(null);
    } else {
      setSpeakingId(item.id);
      await speak(item.translatedText, item.targetLang);
      // Reset after approximate duration
      setTimeout(() => setSpeakingId(null), item.translatedText.length * 100);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Translate & Speak</Text>
      
      <TextInput
        placeholder="Enter text to translate..."
        style={styles.input}
        value={inputText}
        onChangeText={setInputText}
        multiline
      />

      <Text style={styles.label}>From:</Text>
      <Picker
        selectedValue={sourceLang}
        onValueChange={setSourceLang}
        style={styles.picker}
      >
        {LANGUAGES.map(lang => (
          <Picker.Item key={lang.code} label={lang.label} value={lang.code} />
        ))}
      </Picker>

      <Text style={styles.label}>To:</Text>
      <Picker
        selectedValue={targetLang}
        onValueChange={setTargetLang}
        style={styles.picker}
      >
        {LANGUAGES.map(lang => (
          <Picker.Item key={lang.code} label={lang.label} value={lang.code} />
        ))}
      </Picker>

      <Button
        title="Translate"
        onPress={() => navigation.navigate('Result')}
        disabled={!inputText.trim()}
      />

      {/* History Section */}
      <View style={styles.historySection}>
        <View style={styles.historyHeader}>
          <Text style={styles.historyTitle}>History</Text>
          {history.length > 0 && (
            <Button title="Clear" onPress={clearHistory} color="#FF3B30" />
          )}
        </View>

        {history.length === 0 ? (
          <Text style={styles.emptyText}>No translations yet</Text>
        ) : (
          history.map((item) => (
            <TouchableOpacity
              key={item.id}
              style={styles.historyItem}
              onPress={() => handleHistoryItemPress(item)}
            >
              <View style={styles.historyContent}>
                <View style={styles.historyTextSection}>
                  <View style={styles.historyRow}>
                    <Text style={styles.langBadge}>{item.sourceLang.toUpperCase()}</Text>
                    <Text style={styles.arrow}>→</Text>
                    <Text style={styles.langBadge}>{item.targetLang.toUpperCase()}</Text>
                  </View>
                  <Text style={styles.historySource} numberOfLines={2}>{item.sourceText}</Text>
                  <Text style={styles.historyTranslated} numberOfLines={2}>{item.translatedText}</Text>
                </View>
                
                {/* Speaker Button */}
                <TouchableOpacity
                  style={[
                    styles.speakerIconButton,
                    speakingId === item.id && styles.speakerIconButtonActive
                  ]}
                  onPress={(e) => handleSpeakHistory(item, e)}
                >
                  <Text style={styles.speakerIconText}>
                    {speakingId === item.id ? '⏸️' : '🔊'}
                  </Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    padding: 20,
    flex: 1,
    backgroundColor: '#fff',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  input: {
    borderColor: '#ccc',
    borderWidth: 1,
    padding: 10,
    marginBottom: 16,
    borderRadius: 5,
    minHeight: 80,
  },
  label: {
    fontSize: 16,
    marginBottom: 5,
    fontWeight: '600',
  },
  picker: {
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ccc',
  },
  historySection: {
    marginTop: 30,
    paddingTop: 20,
    borderTopWidth: 1,
    borderTopColor: '#ddd',
    marginBottom: 30,
  },
  historyHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  historyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  emptyText: {
    color: '#999',
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: 20,
  },
  historyItem: {
    backgroundColor: '#f8f8f8',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
    borderLeftWidth: 3,
    borderLeftColor: '#007AFF',
  },
  historyContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  historyTextSection: {
    flex: 1,
    marginRight: 10,
  },
  historyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  langBadge: {
    backgroundColor: '#007AFF',
    color: 'white',
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 4,
    fontSize: 12,
    fontWeight: 'bold',
  },
  arrow: {
    marginHorizontal: 8,
    fontSize: 16,
    color: '#666',
  },
  historySource: {
    fontSize: 14,
    marginBottom: 4,
    color: '#333',
  },
  historyTranslated: {
    fontSize: 14,
    fontWeight: '600',
    color: '#007AFF',
  },
  speakerIconButton: {
    backgroundColor: '#007AFF',
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 3,
  },
  speakerIconButtonActive: {
    backgroundColor: '#FF3B30',
  },
  speakerIconText: {
    fontSize: 20,
  },
});
