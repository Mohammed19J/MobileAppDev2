import { useEffect, useState } from "react";
import { SafeAreaView, Text, StyleSheet } from "react-native";
import { Accelerometer } from "expo-sensors";

export default function App() {
  const [data, setData] = useState({ x: 0, y: 0, z: 0 });
  const [isLevel, setIsLevel] = useState(false);

  useEffect(() => {
    Accelerometer.setUpdateInterval(200); 
    const sub = Accelerometer.addListener((reading) => {
      setData(reading);
      const flat = Math.abs(reading.z) > 0.9 && Math.abs(reading.x) < 0.1 && Math.abs(reading.y) < 0.1;
      setIsLevel(flat);
    });
    return () => sub && sub.remove();
  }, []);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: isLevel ? "green" : "red" }]}>
      <Text style={styles.text}>{isLevel ? "LEVEL" : "NOT LEVEL"}</Text>
      <Text style={styles.small}>
        x: {data.x.toFixed(2)} y: {data.y.toFixed(2)} z: {data.z.toFixed(2)}
      </Text>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: "center", justifyContent: "center" },
  text: { fontSize: 32, fontWeight: "bold", color: "white" },
  small: { fontSize: 14, color: "white", marginTop: 8 },
});
