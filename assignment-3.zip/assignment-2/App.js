import { SafeAreaView, StatusBar } from "react-native";
import { Provider as PaperProvider, MD3LightTheme } from "react-native-paper";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import WeatherScreen from "./src/screens/WeatherScreen";
import ForecastScreen from "./src/screens/ForecastScreen";

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <PaperProvider theme={MD3LightTheme}>
      <SafeAreaView style={{ flex: 1, backgroundColor: MD3LightTheme.colors.background }}>
        <StatusBar barStyle="dark-content" backgroundColor={MD3LightTheme.colors.background} />
        <NavigationContainer>
          <Stack.Navigator>
            <Stack.Screen name="Weather" component={WeatherScreen} options={{ headerShown: false }} />
            <Stack.Screen name="Forecast" component={ForecastScreen} options={{ title: "Forecast" }} />
          </Stack.Navigator>
        </NavigationContainer>
      </SafeAreaView>
    </PaperProvider>
  );
}
