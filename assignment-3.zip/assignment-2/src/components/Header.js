import { Appbar } from "react-native-paper";

export default function Header({ title }) {
  return (
    <Appbar.Header mode="center-aligned" elevated>
      <Appbar.Content title={title} />
    </Appbar.Header>
  );
}
