import { View, StyleSheet, Platform } from "react-native";
import { TextInput, IconButton } from "react-native-paper";

export default function CityInput({ value, onChangeText, onClear, onSubmit }) {
  return (
    <View style={styles.row}>
      <TextInput
        mode="outlined"
        style={styles.input}
        placeholder="Enter city…"
        value={value}
        onChangeText={onChangeText}
        returnKeyType="search"
        onSubmitEditing={onSubmit}
      />
      <IconButton icon="close" onPress={onClear} />
    </View>
  );
}
const styles = StyleSheet.create({
  row:{ flexDirection:"row", alignItems:"center", gap:8, paddingHorizontal:16, paddingTop: Platform.select({ios:8, android:4}) },
  input:{ flex:1 },
});
