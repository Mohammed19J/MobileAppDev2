import { View, StyleSheet } from "react-native";
import { Button } from "react-native-paper";

export default function PrimaryButton({ title, onPress, disabled, mode="contained" }) {
  return (
    <View style={styles.wrapper}>
      <Button mode={mode} onPress={onPress} disabled={disabled}>{title}</Button>
    </View>
  );
}
const styles = StyleSheet.create({ wrapper:{ marginTop:12, marginHorizontal:16 }});
