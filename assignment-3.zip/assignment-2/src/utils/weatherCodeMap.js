export const weatherCodeMap = {
  0: "☀️",
  1: "⛅",
  2: "☁️",
  3: "🌧️",
  4: "⛈️",
  5: "❄️",
};

export const iconFromCode = (code) => weatherCodeMap[code] ?? "❓";
