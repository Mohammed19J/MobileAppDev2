import "react-native-gesture-handler";
import { SafeAreaView, StatusBar } from "react-native";
import { Provider as PaperProvider, MD3LightTheme } from "react-native-paper";
import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createDrawerNavigator } from "@react-navigation/drawer";

import WeatherScreen from "./src/screens/WeatherScreen";
import ForecastScreen from "./src/screens/ForecastScreen";
import { WeatherProvider } from "./src/context/WeatherContext";

// Toggle here: "stack" | "tabs" | "drawer"
const NAV_STYLE = "tabs";

const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();
const Drawer = createDrawerNavigator();

function WeatherStack() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Weather" component={WeatherScreen} options={{ headerShown: false }} />
      <Stack.Screen name="Forecast" component={ForecastScreen} options={{ title: "Forecast" }} />
    </Stack.Navigator>
  );
}

function AppTabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Home" component={WeatherStack} options={{ title: "Weather" }} />
      {/* No initialParams here; Forecast reads city/unit from context */}
      <Tab.Screen name="ForecastTab" component={ForecastScreen} options={{ title: "Forecast" }} />
    </Tab.Navigator>
  );
}

function AppDrawer() {
  return (
    <Drawer.Navigator>
      <Drawer.Screen name="WeatherDrawer" component={WeatherStack} options={{ title: "Weather" }} />
      {/* No initialParams; uses context */}
      <Drawer.Screen name="ForecastDrawer" component={ForecastScreen} options={{ title: "Forecast" }} />
    </Drawer.Navigator>
  );
}

export default function App() {
  return (
    <PaperProvider theme={MD3LightTheme}>
      <SafeAreaView style={{ flex: 1, backgroundColor: MD3LightTheme.colors.background }}>
        <StatusBar barStyle="dark-content" backgroundColor={MD3LightTheme.colors.background} />
        <WeatherProvider>
          <NavigationContainer>
            {NAV_STYLE === "tabs" ? (
              <AppTabs />
            ) : NAV_STYLE === "drawer" ? (
              <AppDrawer />
            ) : (
              <WeatherStack />
            )}
          </NavigationContainer>
        </WeatherProvider>
      </SafeAreaView>
    </PaperProvider>
  );
}
