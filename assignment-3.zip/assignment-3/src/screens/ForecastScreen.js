import { useMemo } from "react";
import { View, FlatList, StyleSheet } from "react-native";
import { Text, SegmentedButtons } from "react-native-paper";
import { getMockForecast } from "../utils/mockForecast";
import ForecastItem from "../components/ForecastItem";
import { useWeather } from "../context/WeatherContext";

export default function ForecastScreen() {
  const { city, unit, setUnit } = useWeather();

  const data = useMemo(() => getMockForecast(city, 20), [city]);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text variant="titleLarge">{city} — 24h Forecast</Text>
        <SegmentedButtons
          value={unit}
          onValueChange={setUnit}
          buttons={[{ value: "C", label: "°C" }, { value: "F", label: "°F" }]}
          density="small"
          style={{ marginTop: 8 }}
        />
      </View>

      <FlatList
        data={data}
        keyExtractor={(it) => it.id}
        renderItem={({ item }) => <ForecastItem item={item} unit={unit} />}
        contentContainerStyle={{ padding: 12 }}
        ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerRow: { paddingHorizontal: 12, paddingTop: 12, paddingBottom: 4 },
});
