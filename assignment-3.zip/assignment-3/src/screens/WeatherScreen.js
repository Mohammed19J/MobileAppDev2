import { useState } from "react";
import {
  SafeAreaView,
  StatusBar,
  View,
  StyleSheet,
  Platform,
  KeyboardAvoidingView,
  ScrollView,
} from "react-native";
import {
  FAB,
  Portal,
  useTheme,
  Banner,
  Chip,
  SegmentedButtons,
  Snackbar,
  Text,
} from "react-native-paper";
import Header from "../components/Header";
import CityInput from "../components/CityInput";
import WeatherPanel from "../components/WeatherPanel";
import { getMockWeather } from "../utils/mockWeather";
import { useWeather } from "../context/WeatherContext";

const QUICK_CITIES = ["Tampere", "Helsinki", "Oulu", "Paris"];

export default function WeatherScreen({ navigation }) {
  const theme = useTheme();
  const { city, setCity, unit, setUnit } = useWeather();

  const [loading, setLoading] = useState(false);
  const [data, setData] = useState(getMockWeather(city));
  const [showBanner, setShowBanner] = useState(true);
  const [snack, setSnack] = useState({ visible: false, msg: "" });

  const updateWeather = () => {
    const next = getMockWeather(city);
    setData(next);
    setSnack({ visible: true, msg: `Updated weather for ${next.city}` });
  };

  const simulateLoad = () => {
    setLoading(true);
    setTimeout(() => {
      updateWeather();
      setLoading(false);
    }, 900);
  };

  const clearCity = () => setCity("");

  const openForecast = () => {
    navigation.navigate("Forecast");
  };

  return (
    <SafeAreaView
      style={[
        styles.safe,
        {
          backgroundColor: theme.colors.background,
          paddingTop: Platform.OS === "android" ? (StatusBar.currentHeight ?? 0) : 0,
        },
      ]}
    >
      <StatusBar
        barStyle={theme.dark ? "light-content" : "dark-content"}
        backgroundColor={theme.colors.background}
      />
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : undefined}
      >
        <ScrollView contentContainerStyle={styles.scroll}>
          <Header title="Weather Now" />

          <Banner
            visible={showBanner}
            icon="information-outline"
            actions={[{ label: "Hide", onPress: () => setShowBanner(false) }]}
            style={{ marginHorizontal: 12, marginTop: 8 }}
          >
            Showing <Text style={{ fontWeight: "bold" }}>mock</Text> data. Update to refresh the city; use chips for quick cities and switch °C/°F.
          </Banner>

          <CityInput value={city} onChangeText={setCity} onClear={clearCity} onSubmit={updateWeather} />

          <View style={styles.chipsRow}>
            {QUICK_CITIES.map((c) => (
              <Chip key={c} selected={city === c} onPress={() => setCity(c)} style={styles.chip}>
                {c}
              </Chip>
            ))}
          </View>

          <View style={styles.unitRow}>
            <SegmentedButtons
              value={unit}
              onValueChange={setUnit}
              buttons={[{ value: "C", label: "°C" }, { value: "F", label: "°F" }]}
              density="small"
            />
          </View>

          <WeatherPanel
            data={data}
            loading={loading}
            onUpdate={updateWeather}
            onOpenForecast={openForecast}
            unit={unit}
          />

          <Portal>
            <FAB icon="refresh" onPress={updateWeather} style={styles.fab} />
            <Snackbar
              visible={snack.visible}
              onDismiss={() => setSnack((s) => ({ ...s, visible: false }))}
              duration={2200}
              action={{ label: "OK", onPress: () => {} }}
              style={{ marginBottom: 24 }}
            >
              {snack.msg}
            </Snackbar>
          </Portal>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1 },
  scroll: { paddingBottom: 96 },
  chipsRow: { flexDirection: "row", flexWrap: "wrap", paddingHorizontal: 12, marginTop: 8 },
  chip: { marginRight: 8, marginBottom: 8 },
  unitRow: { paddingHorizontal: 12, marginTop: 4, marginBottom: 8, alignItems: "flex-start" },
  fab: { position: "absolute", right: 16, bottom: 24 },
});
