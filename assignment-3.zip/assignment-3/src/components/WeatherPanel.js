import { View, StyleSheet } from "react-native";
import { Card, Text, ActivityIndicator, Divider } from "react-native-paper";
import PrimaryButton from "./PrimaryButton";
import { iconFromCode } from "../utils/weatherCodeMap";

function toF(c) {
  return Math.round((c * 9) / 5 + 32);
}

export default function WeatherPanel({ data, loading, onUpdate, onOpenForecast, unit = "C" }) {
  if (loading) {
    return (
      <View style={styles.center}>
        <ActivityIndicator />
        <Text style={{ marginTop: 12 }}>Loading…</Text>
      </View>
    );
  }
  const { city, tempC, windKmh, code } = data ?? {};
  const shownTemp = unit === "F" ? toF(tempC) : tempC;
  const tempLabel = unit === "F" ? "°F" : "°C";

  return (
    <View style={styles.wrap}>
      <Card mode="elevated">
        <Card.Title title={city} />
        <Card.Content>
          <View style={styles.rowCenter}>
            <Text style={styles.icon} variant="displayMedium">{iconFromCode(code)}</Text>
            <Text variant="displaySmall" style={styles.temp}>{shownTemp}{tempLabel}</Text>
          </View>
          <Divider style={{ marginVertical: 8 }} />
          <View style={styles.rowSpace}>
            <Text>Wind</Text>
            <Text>{windKmh} km/h</Text>
          </View>
        </Card.Content>
        <Card.Actions style={styles.actions}>
          <PrimaryButton title="Update" onPress={onUpdate} />
          <PrimaryButton title="Open Forecast" onPress={onOpenForecast} mode="outlined" />
        </Card.Actions>
      </Card>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap:{ flex:3, padding:16, justifyContent:"center" },
  rowCenter:{ flexDirection:"row", alignItems:"center", marginBottom:12 },
  rowSpace:{ flexDirection:"row", alignItems:"center", justifyContent:"space-between" },
  icon:{ lineHeight:56, marginRight:12 },
  temp:{},
  center:{ flex:3, alignItems:"center", justifyContent:"center", padding:16 },
  actions: { flexWrap: "wrap", justifyContent: "flex-end" },
});
