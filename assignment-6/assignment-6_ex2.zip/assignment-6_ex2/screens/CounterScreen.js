import React from 'react';
import { View, Text, Button } from 'react-native';
import { useCounter } from '../store/useCounter';

export default function CounterScreen({ navigation }) {
  const { count, increase, decrease, reset } = useCounter();

  const clearPersisted = async () => {
    await useCounter.persist.clearStorage();
    useCounter.setState({ count: 0 });
  };

  return (
    <View>
      <Text style={{ fontSize: 24 }}>Counter</Text>
      <Text style={{ fontSize: 36 }}>{count}</Text>

      <Button title="+1" onPress={increase} />
      <Button title="-1" onPress={decrease} />
      <Button title="Reset (in memory)" onPress={reset} />

      <Button title="Go to Display" onPress={() => navigation.navigate('Display')} />

      <Text style={{ marginTop: 16 }} />
      <Button title="Reset data (clear storage)" onPress={clearPersisted} />
    </View>
  );
}
