import React from 'react';
import { View, Text, Button } from 'react-native';
import { useCounter } from '../store/useCounter';

export default function DisplayScreen({ navigation }) {
  const count = useCounter((s) => s.count);

  return (
    <View>
      <Text style={{ fontSize: 24 }}>Current Value</Text>
      <Text style={{ fontSize: 36 }}>{count}</Text>
      <Button title="Back to Counter" onPress={() => navigation.navigate('Counter')} />
    </View>
  );
}
