import { create } from 'zustand';

export const useCounter = create((set) => ({
  count: 0,
  increase: () => set((s) => ({ count: s.count + 1 })),
  decrease: () => set((s) => ({ count: s.count - 1 })),
  reset: () => set({ count: 0 }),
}));
