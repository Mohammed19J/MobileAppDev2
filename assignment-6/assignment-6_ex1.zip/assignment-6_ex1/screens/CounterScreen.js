import React from 'react';
import { View, Text, Button } from 'react-native';
import { useCounter } from '../store/useCounter';

export default function CounterScreen({ navigation }) {
  const { count, increase, decrease, reset } = useCounter();

  return (
    <View>
      <Text style={{ fontSize: 28 }}>Counter</Text>
      <Text style={{ fontSize: 40 }}>{count}</Text>

      <Button title="+1" onPress={increase} />
      <Button title="-1" onPress={decrease} />
      <Button title="Reset" onPress={reset} />
      <Button title="Go to Display" onPress={() => navigation.navigate('Display')} />
    </View>
  );
}
