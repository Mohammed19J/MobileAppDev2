import { useEffect, useState } from "react";
import { 
  SafeAreaView, 
  View, 
  Text, 
  TextInput, 
  Pressable, 
  StyleSheet, 
  Alert, 
  Platform, 
  StatusBar 
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function App() {
  const [city, setCity] = useState("");
  const [units, setUnits] = useState("metric");
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const savedCity = await AsyncStorage.getItem("@tj_fav_city");
        const savedUnits = await AsyncStorage.getItem("@tj_units");
        if (savedCity !== null) setCity(savedCity);
        if (savedUnits === "metric" || savedUnits === "imperial") setUnits(savedUnits);
      } catch (e) {
        console.warn("Failed to load settings", e);
      } finally {
        setLoaded(true);
      }
    })();
  }, []);

  const saveSettings = async () => {
    try {
      await AsyncStorage.setItem("@tj_fav_city", city.trim());
      await AsyncStorage.setItem("@tj_units", units);
      Alert.alert("Saved", "Your settings have been saved locally.");
    } catch (e) {
      Alert.alert("Error", "Failed to save settings.");
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <Text style={styles.title}>Travel Journal — Settings</Text>

        <View style={styles.section}>
          <Text style={styles.label}>Favourite city</Text>
          <TextInput
            value={city}
            onChangeText={setCity}
            placeholder="e.g., Kyoto"
            autoCorrect={false}
            style={styles.input}
            editable={loaded}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.label}>Measurement units</Text>
          <View style={styles.toggleRow}>
            <Pressable
              onPress={() => setUnits("metric")}
              style={[styles.toggleBtn, units === "metric" && styles.toggleBtnActive]}
            >
              <Text style={[styles.toggleText, units === "metric" && styles.toggleTextActive]}>
                Metric
              </Text>
            </Pressable>
            <Pressable
              onPress={() => setUnits("imperial")}
              style={[styles.toggleBtn, units === "imperial" && styles.toggleBtnActive]}
            >
              <Text style={[styles.toggleText, units === "imperial" && styles.toggleTextActive]}>
                Imperial
              </Text>
            </Pressable>
          </View>
        </View>

        <Pressable onPress={saveSettings} style={styles.saveBtn} disabled={!loaded}>
          <Text style={styles.saveText}>Save</Text>
        </Pressable>

        <Text style={styles.helper}>
          Values are stored with AsyncStorage and automatically loaded on app start.
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#fff",
    paddingTop: Platform.OS === "android" ? StatusBar.currentHeight : 0,
  },
  container: { flex: 1, padding: 20, justifyContent: "flex-start" },
  title: { fontSize: 22, fontWeight: "700", marginBottom: 24 },
  section: { marginBottom: 20 },
  label: { fontSize: 16, marginBottom: 8 },
  input: {
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 16,
  },
  toggleRow: { flexDirection: "row", gap: 12 },
  toggleBtn: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#ccc",
    alignItems: "center",
  },
  toggleBtnActive: {
    borderColor: "#1e90ff",
    backgroundColor: "#eaf3ff",
  },
  toggleText: { fontSize: 16 },
  toggleTextActive: { fontWeight: "700", color: "#1e90ff" },
  saveBtn: {
    marginTop: 8,
    backgroundColor: "#1e90ff",
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: "center",
  },
  saveText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  helper: { marginTop: 10, color: "#666" },
});
