import { useRef, useState } from "react";
import { StyleSheet, Text, View, TouchableOpacity, Image, SafeAreaView, Linking } from "react-native";
import { CameraView, useCameraPermissions } from "expo-camera";

export default function App() {
  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef(null);
  const [facing, setFacing] = useState("back");
  const [photo, setPhoto] = useState(null);

  if (!permission) {
    return (
      <SafeAreaView style={styles.center}>
        <Text style={styles.subtle}>Checking camera permission…</Text>
      </SafeAreaView>
    );
  }

  if (!permission.granted) {
    return (
      <SafeAreaView style={styles.center}>
        <Text style={styles.title}>We need your permission</Text>
        <Text style={styles.subtle}>
          This app uses your camera to take a photo. Please grant permission.
        </Text>

        <TouchableOpacity style={styles.primaryBtn} onPress={requestPermission}>
          <Text style={styles.primaryBtnText}>Grant Camera Permission</Text>
        </TouchableOpacity>

        {!permission.canAskAgain && (
          <TouchableOpacity
            style={styles.secondaryBtn}
            onPress={() => Linking.openSettings?.()}
          >
            <Text style={styles.secondaryBtnText}>Open Settings</Text>
          </TouchableOpacity>
        )}
      </SafeAreaView>
    );
  }

  const takePhoto = async () => {
    try {
      if (!cameraRef.current) return;
      const pic = await cameraRef.current.takePictureAsync({
        quality: 0.7,
        skipProcessing: true,
      });
      setPhoto(pic);
    } catch (e) {
      console.warn("Failed to take photo:", e);
    }
  };

  const flip = () => setFacing((f) => (f === "back" ? "front" : "back"));

  return (
    <View style={styles.container}>
      <CameraView
        ref={cameraRef}
        facing={facing}
        style={StyleSheet.absoluteFill}
        enableZoomGesture
      />

      <SafeAreaView pointerEvents="box-none" style={styles.overlay}>
        <View style={styles.topBar}>
          <TouchableOpacity style={styles.flipBtn} onPress={flip}>
            <Text style={styles.flipText}>Flip</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.bottomBar}>
          <TouchableOpacity onPress={takePhoto} style={styles.shutterOuter}>
            <View style={styles.shutterInner} />
          </TouchableOpacity>

          {photo?.uri ? (
            <Image source={{ uri: photo.uri }} style={styles.thumb} />
          ) : (
            <View style={[styles.thumb, styles.thumbPlaceholder]}>
              <Text style={styles.subtle}>No photo</Text>
            </View>
          )}
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#000" },
  overlay: {
    flex: 1,
    justifyContent: "space-between",
  },
  topBar: {
    paddingHorizontal: 16,
    paddingTop: 8,
    alignItems: "flex-end",
  },
  bottomBar: {
    paddingHorizontal: 24,
    paddingBottom: 24,
    alignItems: "center",
    gap: 12,
  },

  flipBtn: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    backgroundColor: "rgba(0,0,0,0.35)",
    borderRadius: 12,
  },
  flipText: { color: "#fff", fontWeight: "600" },

  shutterOuter: {
    width: 78,
    height: 78,
    borderRadius: 39,
    borderWidth: 4,
    borderColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
  shutterInner: {
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: "#fff",
  },

  thumb: {
    position: "absolute",
    right: 0,
    bottom: 16,
    width: 72,
    height: 72,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: "rgba(255,255,255,0.9)",
    overflow: "hidden",
  },
  thumbPlaceholder: {
    backgroundColor: "rgba(255,255,255,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },

  center: {
    flex: 1,
    padding: 24,
    alignItems: "center",
    justifyContent: "center",
    gap: 16,
    backgroundColor: "#0b0b0b",
  },
  title: { fontSize: 20, fontWeight: "700", color: "#fff", textAlign: "center" },
  subtle: { color: "rgba(255,255,255,0.8)", textAlign: "center" },

  primaryBtn: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: "#3b82f6",
    borderRadius: 10,
    minWidth: 220,
    alignItems: "center",
  },
  primaryBtnText: { color: "#fff", fontWeight: "700" },

  secondaryBtn: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    backgroundColor: "transparent",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "rgba(255,255,255,0.35)",
    minWidth: 220,
    alignItems: "center",
  },
  secondaryBtnText: { color: "#fff", fontWeight: "600" },
});
