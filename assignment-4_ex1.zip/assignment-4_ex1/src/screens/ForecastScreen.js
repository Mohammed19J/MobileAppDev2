import { useEffect, useState} from "react";
import { View, FlatList, StyleSheet } from "react-native";
import { Text, SegmentedButtons, ActivityIndicator } from "react-native-paper";
import ForecastItem from "../components/ForecastItem";
import { useWeather } from "../context/WeatherContext";
import { fetchHourlyForecastByCity } from "../utils/api";

export default function ForecastScreen() {
  const { city, unit, setUnit } = useWeather();
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState([]);
  const [titleCity, setTitleCity] = useState(city);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        setLoading(true);
        const res = await fetchHourlyForecastByCity(city, 24);
        if (!mounted) return;
        setItems(res.items);
        setTitleCity(res.city);
      } catch (e) {
        setItems([]);
      } finally {
        setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, [city]);

  return (
    <View style={styles.container}>
      <View style={styles.headerRow}>
        <Text variant="titleLarge">{titleCity} — 24h Forecast</Text>
        <SegmentedButtons
          value={unit}
          onValueChange={setUnit}
          buttons={[{ value: "C", label: "°C" }, { value: "F", label: "°F" }]}
          density="small"
          style={{ marginTop: 8 }}
        />
      </View>

      {loading ? (
        <View style={{ padding: 16 }}>
          <ActivityIndicator />
        </View>
      ) : (
        <FlatList
          data={items}
          keyExtractor={(it) => it.id}
          renderItem={({ item }) => <ForecastItem item={item} unit={unit} />}
          contentContainerStyle={{ padding: 12 }}
          ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
          ListEmptyComponent={<Text style={{ padding: 16 }}>No data.</Text>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  headerRow: { paddingHorizontal: 12, paddingTop: 12, paddingBottom: 4 },
});
