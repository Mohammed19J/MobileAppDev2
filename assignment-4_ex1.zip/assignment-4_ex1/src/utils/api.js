import { descFromCode } from "../utils/weatherCodeMap";

const GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search";
const FORECAST_URL = "https://api.open-meteo.com/v1/forecast";

const FALLBACK_COORDS = {
  helsinki: { name: "Helsinki", country: "Finland", lat: 60.1699, lon: 24.9384 },
  tampere:  { name: "Tampere",  country: "Finland", lat: 61.4978, lon: 23.7610 },
  oulu:     { name: "Oulu",     country: "Finland", lat: 65.0121, lon: 25.4651 },
  paris:    { name: "Paris",    country: "France",  lat: 48.8566, lon: 2.3522  },
};

async function httpGet(url) {
  try {
    const res = await fetch(url);
    if (!res.ok) {
      const txt = await res.text().catch(() => "");
      throw new Error(`HTTP ${res.status} ${res.statusText}: ${txt || "(no body)"}`);
    }
    return res.json();
  } catch (err) {
    console.log("[api] GET failed:", url, err);
    throw err;
  }
}

async function geocodeCity(name) {
  const raw = (name || "").trim();
  if (!raw) throw new Error("Empty city name");
  const url = `${GEOCODE_URL}?name=${encodeURIComponent(raw)}&count=1&language=en&format=json`;
  try {
    const data = await httpGet(url);
    const first = data?.results?.[0];
    if (!first) throw new Error(`City not found: "${raw}"`);
    return {
      displayName: raw,
      name: first.name || raw,
      lat: first.latitude,
      lon: first.longitude,
      country: first.country,
    };
  } catch (e) {
    console.log("[api] geocode fallback engaged for:", raw, e);
    const key = raw.toLowerCase();
    const fb = FALLBACK_COORDS[key];
    if (fb) {
      return {
        displayName: fb.name,
        name: fb.name,
        lat: fb.lat,
        lon: fb.lon,
        country: fb.country,
      };
    }
    throw e;
  }
}

async function fetchBundle(lat, lon) {
  const params = new URLSearchParams({
    latitude: String(lat),
    longitude: String(lon),
    timezone: "auto",
    current: "temperature_2m,wind_speed_10m,weather_code",
    hourly: "temperature_2m,wind_speed_10m,weather_code",
    wind_speed_unit: "kmh",
  });
  const url = `${FORECAST_URL}?${params.toString()}`;
  return httpGet(url);
}

export async function fetchCurrentWeatherByCity(cityInput) {
  const place = await geocodeCity(cityInput);
  const data = await fetchBundle(place.lat, place.lon);
  const c = data.current ?? {};
  return {
    city: `${place.displayName}${place.country ? ", " + place.country : ""}`,
    tempC: Math.round(c.temperature_2m ?? 0),
    windKmh: Math.round(c.wind_speed_10m ?? 0),
    code: c.weather_code ?? 2,
  };
}

export async function fetchHourlyForecastByCity(cityInput, hours = 24) {
  const place = await geocodeCity(cityInput);
  const data = await fetchBundle(place.lat, place.lon);

  const times = data.hourly?.time ?? [];
  const temps = data.hourly?.temperature_2m ?? [];
  const winds = data.hourly?.wind_speed_10m ?? [];
  const codes = data.hourly?.weather_code ?? [];

  const currentIso = data.current?.time ?? null;
  let startIdx = 0;
  if (currentIso) {
    const idx = times.findIndex((t) => t >= currentIso);
    startIdx = idx >= 0 ? idx : 0;
  }

  const sliced = times.slice(startIdx, startIdx + hours).map((iso, i) => {
    const [date, time] = String(iso).split("T");
    const idx = startIdx + i;
    const code = codes[idx] ?? 2;
    const windKmh = Math.round(winds[idx] ?? 0);
    return {
      id: iso,
      when: { date, time },
      tempC: Math.round(temps[idx] ?? 0),
      windKmh,
      windMs: Math.round((windKmh / 3.6) * 10) / 10,
      desc: descFromCode(code),
      code,
    };
  });

  return {
    city: `${place.displayName}${place.country ? ", " + place.country : ""}`,
    items: sliced,
  };
}
