export const weatherCodeMap = {
  0: "☀️", 1: "🌤️", 2: "⛅", 3: "☁️", 4: "⛈️", 5: "❄️",
  45: "🌫️", 48: "🌫️",
  51: "🌦️", 53: "🌦️", 55: "🌦️",
  61: "🌧️", 63: "🌧️", 65: "🌧️",
  66: "🌧️", 67: "🌧️",
  71: "🌨️", 73: "🌨️", 75: "❄️",
  77: "❄️",
  80: "🌧️", 81: "🌧️", 82: "🌧️",
  85: "🌨️", 86: "🌨️",
  95: "⛈️", 96: "⛈️", 99: "⛈️",
};

export const iconFromCode = (code, opts = {}) => {
  const isNight = !!opts.night;

  if (isNight) {
    switch (code) {
      case 0: return "🌙";     
      case 1: return "🌙";     
      case 2: return "☁️";    
      case 3: return "☁️";    
      case 45:
      case 48: return "🌫️";  
      default:
        return weatherCodeMap[code] ?? "❓";
    }
  }

  return weatherCodeMap[code] ?? "❓";
};

export const descFromCode = (code) => {
  const map = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Depositing rime fog",
    51: "Light drizzle", 53: "Moderate drizzle", 55: "Dense drizzle",
    61: "Slight rain", 63: "Moderate rain", 65: "Heavy rain",
    66: "Light freezing rain", 67: "Heavy freezing rain",
    71: "Slight snow", 73: "Moderate snow", 75: "Heavy snow", 77: "Snow grains",
    80: "Slight rain showers", 81: "Moderate rain showers", 82: "Violent rain showers",
    85: "Slight snow showers", 86: "Heavy snow showers",
    95: "Thunderstorm", 96: "Thunderstorm with hail", 99: "Thunderstorm with heavy hail",
  };
  return map[code] ?? "Unidentified";
};
