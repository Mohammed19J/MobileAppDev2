function hashString(str = "") {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h >>> 0;
}
function makeSeededRng(seed) {
  let x = seed >>> 0;
  return () => {
    x = (x * 1664525 + 1013904223) >>> 0;
    return x / 2 ** 32;
  };
}
function pickInt(rng, min, max) {
  return Math.round(min + rng() * (max - min));
}

export const RANGES = {
  0: { temp: [20, 32], wind: [5, 20] },
  1: { temp: [16, 28], wind: [5, 25] },
  2: { temp: [10, 24], wind: [5, 30] },
  3: { temp: [4, 18],  wind: [10, 40] },
  4: { temp: [8, 22],  wind: [20, 60] },
  5: { temp: [-20, 0], wind: [5, 35] },
};

export function getMockWeather(city) {
  const safeCity = city?.trim() || "Helsinki";
  const code = safeCity.length % 6;

  const rng = makeSeededRng(hashString(safeCity) ^ code);

  const [tMin, tMax] = RANGES[code].temp;
  const [wMin, wMax] = RANGES[code].wind;

  const tempC = pickInt(rng, tMin, tMax);
  const windKmh = pickInt(rng, wMin, wMax);

  return { city: safeCity, tempC, windKmh, code };
}
