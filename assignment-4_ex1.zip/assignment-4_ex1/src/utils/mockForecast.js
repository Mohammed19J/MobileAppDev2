import { RANGES, getMockWeather } from "./mockWeather";

function hashString(str = "") {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return h >>> 0;
}
function makeSeededRng(seed) {
  let x = seed >>> 0;
  return () => {
    x = (x * 1664525 + 1013904223) >>> 0;
    return x / 2 ** 32;
  };
}
function pickInt(rng, min, max) {
  return Math.round(min + rng() * (max - min));
}
function clamp(v, lo, hi) {
  return Math.min(hi, Math.max(lo, v));
}

const DESCS_BY_CODE = [
  "Clear",
  "Partly cloudy",
  "Cloudy",
  "Showers",
  "Thunder",
  "Snow",
];

function fmtDate(d) {
  const mm = d.toLocaleString(undefined, { month: "short" });
  const dd = d.toLocaleString(undefined, { day: "2-digit" });
  return `${mm} ${dd}`;
}
function fmtTime(d) {
  return d.toLocaleString(undefined, {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });
}

export function getMockForecast(city = "Helsinki", n = 16) {
  const safe = (city || "").trim() || "Helsinki";
  const baseSeed = hashString(safe) ^ 0x9e3779b9;
  const rng = makeSeededRng(baseSeed);

  const current = getMockWeather(safe);
  let code = current.code;

  let [tMin, tMax] = RANGES[code].temp;
  let [wMin, wMax] = RANGES[code].wind;

  let tempC = clamp(current.tempC, tMin, tMax);
  let windKmh = clamp(current.windKmh ?? pickInt(rng, wMin, wMax), wMin, wMax);

  const now = new Date();
  const items = [];

  for (let i = 0; i < n; i++) {
    if (i > 0) {
      const r = rng();
      if (r < 0.175) code = Math.max(0, code - 1);
      else if (r < 0.35) code = Math.min(5, code + 1);

      [tMin, tMax] = RANGES[code].temp;
      [wMin, wMax] = RANGES[code].wind;

      tempC = clamp(tempC + pickInt(rng, -2, 2), tMin, tMax);
      windKmh = clamp(windKmh + pickInt(rng, -5, 5), wMin, wMax);
    }

    const t = new Date(now.getTime() + i * 60 * 60 * 1000); 
    const windMs = Math.max(0, Math.round(windKmh / 3.6));

    items.push({
      id: `${safe}-${t.getTime()}`,
      when: { date: fmtDate(t), time: fmtTime(t) },
      tempC: Math.round(tempC),
      windKmh: Math.round(windKmh),
      windMs,
      desc: DESCS_BY_CODE[code],
      code,
    });
  }

  return items;
}
