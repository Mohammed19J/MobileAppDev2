import { View, StyleSheet } from "react-native";
import { Card, Text } from "react-native-paper";
import { iconFromCode } from "../utils/weatherCodeMap";

function toF(c) {
  return Math.round((c * 9) / 5 + 32);
}

export default function ForecastItem({ item, unit = "C" }) {
  const { when, tempC, windMs, windKmh, desc, code } = item;

  const dateStr = String(when?.date ?? "");
  const timeStr = String(when?.time ?? "");

  const hour = Number.parseInt(timeStr.slice(0, 2), 10);
  const isNight = Number.isFinite(hour) ? (hour >= 21 || hour < 6) : false;

  const shownTemp = unit === "F" ? toF(tempC) : Math.round(tempC);
  const tempLabel = unit === "F" ? "°F" : "°C";

  const windKmhValue = Number.isFinite(windKmh) ? windKmh : Math.round((windMs ?? 0) * 3.6);
  const windStr = `${windKmhValue} km/h`;

  const icon = iconFromCode(code, { night: isNight });

  return (
    <Card>
      <Card.Content style={styles.row}>
        <View style={styles.emojiBox}>
          <Text variant="displaySmall" style={styles.emojiText}>{icon}</Text>
        </View>

        <View style={styles.left}>
          <Text variant="labelLarge">{dateStr}</Text>
          <Text variant="bodySmall">{timeStr}</Text>
        </View>

        <View style={styles.mid}>
          <Text variant="titleMedium" style={styles.rightText}>{shownTemp}{tempLabel}</Text>
          <Text variant="bodySmall" style={styles.rightText}>{windStr}</Text>
        </View>

        <View style={styles.right}>
          <Text>{`${icon} ${desc}`}</Text>
        </View>
      </Card.Content>
    </Card>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center" },
  emojiBox: { width: 48, alignItems: "center", marginRight: 8 },
  emojiText: { lineHeight: 40 },
  left: { flex: 1.1, paddingRight: 8 },
  mid: { flex: 1, alignItems: "flex-end", paddingHorizontal: 8 },
  right: { flex: 1.2, alignItems: "flex-end", paddingLeft: 8 },
  rightText: { textAlign: "right" },
});
