import { createContext, useContext, useMemo, useState } from "react";

const WeatherContext = createContext(null);

export function WeatherProvider({ children }) {
  const [city, setCity] = useState("Tampere");
  const [unit, setUnit] = useState("C");

  const value = useMemo(() => ({ city, setCity, unit, setUnit }), [city, unit]);
  return <WeatherContext.Provider value={value}>{children}</WeatherContext.Provider>;
}

export function useWeather() {
  const ctx = useContext(WeatherContext);
  if (!ctx) throw new Error("useWeather must be used within WeatherProvider");
  return ctx;
}
